class PagesController < ApplicationController
  def root
  end
end